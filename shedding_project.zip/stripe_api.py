from fastapi import FastAPI, HTTPException
import stripe

app = FastAPI()

stripe.api_key = "your_secret_key_here"

@app.post("/create-checkout-session/")
async def create_checkout_session(order: dict):
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": order["shed_type"]},
                        "unit_amount": int(order["total_price"] * 100),
                    },
                    "quantity": 1,
                }
            ],
            mode="payment",
            success_url="https://yourdomain.com/success",
            cancel_url="https://yourdomain.com/cancel",
        )
        return {"checkout_url": checkout_session.url}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
