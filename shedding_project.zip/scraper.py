import requests
from bs4 import BeautifulSoup
import json
import time

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
}

SUPPLIERS = {
    "Kent": "https://www.kent.ca",
    "HomeDepot": "https://www.homedepot.ca"
}

CATEGORIES = {
    "Lumber": ["/lumber-category-url"],
    "Roofing": ["/roofing-category-url"],
    "Doors & Windows": ["/doors-windows-category-url"],
    "Insulation": ["/insulation-category-url"]
}

def scrape_supplier(supplier_name, base_url):
    results = []
    for category, urls in CATEGORIES.items():
        for url in urls:
            full_url = base_url + url
            response = requests.get(full_url, headers=HEADERS)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, "html.parser")
                products = soup.find_all("div", class_="product-tile")  # Adjust structure
                for product in products:
                    name = product.find("h2").text.strip() if product.find("h2") else "N/A"
                    price = product.find("span", class_="price").text.strip() if product.find("span", class_="price") else "N/A"
                    link = base_url + product.find("a")["href"] if product.find("a") else "N/A"
                    results.append({"name": name, "price": price, "link": link, "category": category, "supplier": supplier_name})
            time.sleep(1)
    return results

kent_data = scrape_supplier("Kent", SUPPLIERS["Kent"])
home_depot_data = scrape_supplier("HomeDepot", SUPPLIERS["HomeDepot"])

all_data = kent_data + home_depot_data
with open("shed_material_prices.json", "w") as file:
    json.dump(all_data, file, indent=4)
