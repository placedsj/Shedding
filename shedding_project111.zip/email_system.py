from fastapi import FastAPI, HTTPException
import smtplib
from email.mime.text import MIMEText

app = FastAPI()

SMTP_SERVER = "smtp.your-email-provider.com"
SMTP_PORT = 587
EMAIL_USER = "your-email@example.com"
EMAIL_PASS = "your-email-password"

@app.post("/send-confirmation/")
async def send_confirmation_email(customer_email: str, order_id: str):
    try:
        msg = MIMEText(f"Your shed order {order_id} has been confirmed!")
        msg["Subject"] = "Order Confirmation"
        msg["From"] = EMAIL_USER
        msg["To"] = customer_email

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(EMAIL_USER, EMAIL_PASS)
            server.sendmail(EMAIL_USER, customer_email, msg.as_string())

        return {"message": "Confirmation email sent successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
